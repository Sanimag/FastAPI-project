# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['source_folder',
 'source_folder.alembic',
 'source_folder.alembic.versions',
 'source_folder.conn']

package_data = \
{'': ['*']}

install_requires = \
['alembic>=1.8.1,<2.0.0',
 'dotenv>=0.0.5,<0.0.6',
 'fastapi-sqlalchemy>=0.2.1,<0.3.0',
 'fastapi>=0.86.0,<0.87.0',
 'graphene>=3.1.1,<4.0.0',
 'graphql-core>=3.2.3,<4.0.0',
 'psycopg2-binary>=2.9.5,<3.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'strawberry-graphql[fastapi]>=0.140.3,<0.141.0',
 'uvicorn>=0.19.0,<0.20.0']

setup_kwargs = {
    'name': 'source-folder',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
